#!/usr/bin/env python3
"""
Reconquista V3 — Base de dados de condados com coordenadas históricas.
91 condados extraídos da HIERARQUIA_868AD_V3.md
Cada condado tem: id, nome, lon, lat, ducado, reino, baronias
"""

# Formato: (id, nome_display, lon, lat, ducado, reino, [baronias com coords])
# As coordenadas são centróides históricos (não modernos!)
# Baronias: (nome, lon, lat)

KINGDOMS = {
    "asturias": "Reino das Astúrias",
    "pamplona": "Reino de Pamplona",
    "marca_hispanica": "Marca Hispânica",
    "emirato": "Emirato de Córdoba",
}

DUCHIES = {
    # Astúrias
    "d_asturias":    ("asturias", "Ducado de Astúrias"),
    "d_galiza":      ("asturias", "Ducado de Galiza"),
    "d_portucale":   ("asturias", "Condado de Portucale"),
    "d_leon":        ("asturias", "Ducado de Leão"),
    "d_castela":     ("asturias", "Condado de Castela"),
    "d_vasconia_ast":("asturias", "Territórios Vasconços"),
    "d_fronteira":   ("emirato", "Zona de Expansão / Deserto do Douro"),
    # Pamplona
    "d_navarra":     ("pamplona", "Navarra Própria"),
    "d_vizcaya":     ("pamplona", "Vizcaya"),
    # Marca Hispânica
    "d_aragon":      ("marca_hispanica", "Condado de Aragão"),
    "d_barcelona":   ("marca_hispanica", "Condados sob Bernardo"),
    "d_urgell":      ("marca_hispanica", "Condados sob Guifré"),
    "d_cat_indep":   ("marca_hispanica", "Condados Independentes"),
    # Emirato
    "d_marca_sup":   ("emirato", "Marca Superior"),
    "d_marca_med":   ("emirato", "Marca Média"),
    "d_marca_inf":   ("emirato", "Marca Inferior"),
    "d_gharb":       ("emirato", "Gharb al-Andalus"),
    "d_cordoba":     ("emirato", "Kura Central"),
    "d_sevilla":     ("emirato", "Kura de Sevilha"),
    "d_jaen":        ("emirato", "Kura de Jaén"),
    "d_granada":     ("emirato", "Kura de Granada"),
    "d_malaga":      ("emirato", "Kura de Málaga"),
    "d_almeria":     ("emirato", "Kura de Almería"),
    "d_tudmir":      ("emirato", "Kura de Tudmir"),
    "d_valencia":    ("emirato", "Kura de Valência"),
    "d_baleares":    ("emirato", "Baleares"),
}

# (condado_id, display_name, lon, lat, duchy_id, [(barony_name, lon, lat), ...])
CONDADOS = [
    # ═══ DUCADO DE ASTÚRIAS ═══
    ("oviedo",       "Oviedo",         -5.84, 43.36, "d_asturias",
     [("Oviedo",-5.84,43.36),("Grado",-6.07,43.39),("Siero",-5.66,43.39),("Mieres",-5.77,43.25)]),
    ("pravia",       "Pravia",         -6.10, 43.50, "d_asturias",
     [("Pravia",-6.10,43.50),("Salas",-6.26,43.41),("Tineo",-6.42,43.33),("Luarca",-6.54,43.54)]),
    ("gijon",        "Gijón",          -5.66, 43.54, "d_asturias",
     [("Gijón",-5.66,43.54),("Villaviciosa",-5.43,43.48),("Avilés",-5.92,43.56)]),
    ("liebana",      "Liébana",        -4.73, 43.12, "d_asturias",
     [("Cangas de Onís",-5.13,43.35),("Liébana",-4.73,43.12),("Picos",-4.85,43.20)]),

    # ═══ DUCADO DE GALIZA ═══
    ("coruna",       "Coruña",         -8.40, 43.37, "d_galiza",
     [("Coruña",-8.40,43.37),("Betanzos",-8.21,43.28),("Ferrol",-8.24,43.48)]),
    ("compostela",   "Santiago",        -8.54, 42.88, "d_galiza",
     [("Santiago",-8.54,42.88),("Padrón",-8.66,42.74),("Noia",-8.84,42.79)]),
    ("lugo",         "Lugo",           -7.56, 43.01, "d_galiza",
     [("Lugo",-7.56,43.01),("Sarria",-7.42,42.78),("Monforte",-7.52,42.52)]),
    ("ourense",      "Ourense",        -7.86, 42.34, "d_galiza",
     [("Ourense",-7.86,42.34),("Celanova",-7.96,42.15),("Verín",-7.44,41.94)]),
    ("tui",          "Tui",            -8.65, 42.05, "d_galiza",
     [("Tui",-8.65,42.05),("Vigo",-8.72,42.23),("Pontevedra",-8.65,42.43)]),

    # ═══ CONDADO DE PORTUCALE ═══
    ("porto",        "Porto",          -8.61, 41.15, "d_portucale",
     [("Porto",-8.65,41.16),("Maia",-8.60,41.24),("Matosinhos",-8.69,41.21),("Vila do Conde",-8.70,41.35)]),
    ("braga",        "Braga",          -8.43, 41.55, "d_portucale",
     [("Braga",-8.42,41.56),("Guimarães",-8.28,41.44),("Barcelos",-8.62,41.54),("Famalicão",-8.50,41.40)]),
    ("viana",        "Viana",          -8.83, 41.69, "d_portucale",
     [("Viana do Castelo",-8.83,41.69),("Ponte de Lima",-8.55,41.78),("Caminha",-8.80,41.90)]),
    ("chaves",       "Chaves",         -7.47, 41.74, "d_portucale",
     [("Chaves",-7.47,41.74),("Montalegre",-7.80,41.82),("Vila Pouca",-7.65,41.52),("Vila Real",-7.75,41.28)]),
    ("braganca",     "Bragança",       -6.76, 41.81, "d_portucale",
     [("Bragança",-6.76,41.81),("Miranda do Douro",-6.27,41.49),("Vimioso",-6.52,41.58),("Mogadouro",-6.71,41.34)]),

    # ═══ DUCADO DE LEÃO ═══
    ("leon",         "León",           -5.57, 42.60, "d_leon",
     [("León",-5.57,42.60),("Mansilla",-5.42,42.50),("Sahagún",-5.03,42.37)]),
    ("astorga",      "Astorga",        -6.05, 42.46, "d_leon",
     [("Astorga",-6.05,42.46),("Ponferrada",-6.59,42.55),("Bembibre",-6.42,42.62)]),
    ("benavente",    "Benavente",      -5.68, 42.00, "d_leon",
     [("Benavente",-5.68,42.00),("Villalpando",-5.41,41.86)]),
    ("zamora",       "Zamora",         -5.74, 41.50, "d_leon",
     [("Zamora",-5.74,41.50),("Toro",-5.39,41.52)]),
    ("salamanca",    "Salamanca",      -5.66, 40.97, "d_leon",
     [("Salamanca",-5.66,40.97),("Ciudad Rodrigo",-6.53,40.60),("Alba de Tormes",-5.51,40.82)]),

    # ═══ CONDADO DE CASTELA ═══
    ("burgos",       "Burgos",         -3.70, 42.34, "d_castela",
     [("Burgos",-3.70,42.34),("Lerma",-3.75,42.03)]),
    ("amaya",        "Amaya",          -4.10, 42.70, "d_castela",
     [("Amaya",-4.10,42.70),("Villadiego",-4.01,42.52),("Sedano",-3.73,42.72)]),
    ("osma",         "Osma",           -3.06, 41.57, "d_castela",
     [("Osma",-3.06,41.57),("San Esteban",-3.35,41.73),("El Burgo",-3.15,41.42)]),
    ("palencia",     "Palência",       -4.53, 42.01, "d_castela",
     [("Palencia",-4.53,42.01),("Carrión",-4.60,42.34),("Aguilar",-4.26,42.79)]),
    ("najera",       "Nájera",         -2.73, 42.42, "d_navarra",
     [("Nájera",-2.73,42.42),("Logroño",-2.45,42.47),("Calahorra",-1.97,42.31)]),
    ("valladolid",   "Valladolid",     -4.73, 41.65, "d_leon",
     [("Valladolid",-4.73,41.65),("Medina del Campo",-4.91,41.31),("Olmedo",-4.68,41.29)]),

    # ═══ TERRITÓRIOS VASCONÇOS ═══
    ("alava",        "Álava",          -2.67, 42.85, "d_vasconia_ast",
     [("Vitoria",-2.67,42.85),("Salvatierra",-2.39,42.85)]),
    ("cantabria",    "Cantábria",      -3.80, 43.46, "d_vasconia_ast",
     [("Santander",-3.80,43.46),("Laredo",-3.41,43.41),("Castro Urdiales",-3.22,43.38)]),

    # ═══ FRONTEIRA / PRESÚRIA ═══
    ("lamego",       "Lamego",         -7.81, 41.10, "d_fronteira",
     [("Lamego",-7.82,41.08),("Resende",-8.00,41.09),("Tarouca",-7.75,41.00),("S.J.Pesqueira",-7.48,41.12)]),
    ("viseu",        "Viseu",          -7.91, 40.66, "d_fronteira",
     [("Viseu",-7.88,40.70),("Mangualde",-7.68,40.55),("Tondela",-8.15,40.48),("Aveiro",-8.65,40.64)]),
    ("coimbra",      "Coimbra",        -8.43, 40.21, "d_fronteira",
     [("Coimbra",-8.40,40.22),("Montemor-o-Velho",-8.70,40.10),("Figueira da Foz",-8.88,40.16),("Ovar",-8.63,40.88)]),
    ("leiria",       "Leiria",          -8.81, 39.74, "d_fronteira",
     [("Leiria",-8.81,39.74),("Pombal",-8.63,39.95),("Óbidos",-9.15,39.36)]),
    ("idanha",       "Idanha",         -7.24, 39.92, "d_fronteira",
     [("Idanha-a-Nova",-7.35,39.90),("Guarda",-7.35,40.55),("Covilhã",-7.62,40.25)]),

    # ═══ NAVARRA ═══
    ("pamplona",     "Pamplona",       -1.64, 42.82, "d_navarra",
     [("Pamplona",-1.64,42.82),("Puente la Reina",-1.81,42.67),("Estella",-2.03,42.67)]),
    ("sanguesa",     "Sangüesa",       -1.28, 42.57, "d_navarra",
     [("Sangüesa",-1.28,42.57),("Lumbier",-1.31,42.65)]),

    # ═══ VIZCAYA ═══
    ("vizcaya",      "Vizcaya",        -2.93, 43.26, "d_vizcaya",
     [("Bilbao",-2.93,43.26),("Durango",-2.63,43.17),("Guernica",-2.67,43.31)]),

    # ═══ ARAGÃO ═══
    ("jaca",         "Jaca",           -0.55, 42.57, "d_aragon",
     [("Jaca",-0.55,42.57),("Canfranc",-0.52,42.72)]),
    ("sobrarbe",     "Sobrarbe",        0.16, 42.40, "d_aragon",
     [("Aínsa",0.14,42.42),("Boltaña",0.07,42.44)]),
    ("ribagorza",    "Ribagorça",       0.46, 42.30, "d_aragon",
     [("Benasque",0.52,42.61),("Graus",0.34,42.19)]),

    # ═══ CONDADOS CATALÃES (Bernardo) ═══
    ("barcelona",    "Barcelona",       2.15, 41.38, "d_barcelona",
     [("Barcelona",2.15,41.38),("Terrassa",2.01,41.56),("Sabadell",2.11,41.54)]),
    ("girona",       "Girona",          2.82, 41.98, "d_barcelona",
     [("Girona",2.82,41.98),("Figueres",2.96,42.27)]),
    ("osona",        "Osona/Vic",       2.25, 41.89, "d_barcelona",
     [("Vic",2.25,41.89),("Manresa",1.83,41.73),("Berga",1.85,42.10)]),

    # ═══ CONDADOS CATALÃES (Guifré) ═══
    ("urgell",       "Urgell",          1.30, 42.36, "d_urgell",
     [("La Seu d'Urgell",1.46,42.36),("Balaguer",0.80,41.79)]),
    ("cerdanya",     "Cerdanya",        1.83, 42.44, "d_urgell",
     [("Puigcerdà",1.93,42.43),("Ripoll",2.19,42.20)]),

    # ═══ CONDADOS INDEPENDENTES ═══
    ("empuries",     "Empúries",        3.05, 42.15, "d_cat_indep",
     [("Empúries",3.12,42.13),("Castelló d'Empúries",3.07,42.26),("Roses",3.17,42.26)]),
    ("pallars",      "Pallars",         1.00, 42.48, "d_cat_indep",
     [("Sort",1.13,42.41),("Tremp",0.89,42.17)]),
    ("conflent",     "Conflent",        2.35, 42.55, "d_cat_indep",
     [("Prades",2.42,42.62),("Vilafranca de Conflent",2.37,42.59)]),

    # ═══ MARCA SUPERIOR ═══
    ("zaragoza",     "Saraqusta",      -0.88, 41.65, "d_marca_sup",
     [("Zaragoza",-0.88,41.65),("Calatayud",-1.64,41.35),("Daroca",-1.42,41.11)]),
    ("huesca",       "Wasqa",          -0.41, 42.14, "d_marca_sup",
     [("Huesca",-0.41,42.14),("Barbastro",0.13,42.04),("Monzón",0.19,41.91)]),
    ("lerida",       "Larida",          0.63, 41.61, "d_marca_sup",
     [("Lérida",0.63,41.61),("Fraga",-0.03,41.52)]),
    ("tudela",       "Tudela",         -1.61, 42.07, "d_marca_sup",
     [("Tudela",-1.61,42.07),("Cascante",-1.68,41.97),("Tarazona",-1.73,41.91)]),
    ("tortosa",      "Turtuxa",         0.52, 40.81, "d_marca_sup",
     [("Tortosa",0.52,40.81),("Amposta",0.58,40.71)]),
    ("teruel",       "Tirwal",         -1.11, 40.34, "d_marca_sup",
     [("Teruel",-1.11,40.34),("Albarracín",-1.44,40.41)]),

    # ═══ MARCA MÉDIA ═══
    ("toledo",       "Tulaytula",      -4.00, 39.86, "d_marca_med",
     [("Toledo",-4.00,39.86),("Talavera",-4.83,39.96),("Consuegra",-3.61,39.46)]),
    ("madrid",       "Mayrit",         -3.70, 40.42, "d_marca_med",
     [("Madrid",-3.70,40.42),("Alcalá",-3.36,40.48),("Guadalajara",-3.16,40.63)]),
    ("segovia",      "Shaqubiya",      -4.12, 40.94, "d_marca_med",
     [("Segovia",-4.12,40.94),("Ávila",-4.70,40.66),("Sepúlveda",-3.75,41.30)]),
    ("cuenca",       "Qunka",          -2.13, 40.07, "d_marca_med",
     [("Cuenca",-2.13,40.07),("Huete",-2.69,40.15),("Uclés",-2.86,39.98)]),
    ("medinaceli",   "Madinat Salim",  -2.43, 41.17, "d_marca_med",
     [("Medinaceli",-2.43,41.17),("Sigüenza",-2.64,41.07),("Molina",-1.89,40.84)]),

    # ═══ MARCA INFERIOR ═══
    ("merida",       "Marida",         -6.34, 38.92, "d_marca_inf",
     [("Mérida",-6.34,38.92),("Medellín",-5.96,38.96)]),
    ("badajoz",      "Batalyaws",      -6.97, 38.88, "d_marca_inf",
     [("Badajoz",-6.97,38.88),("Olivenza",-6.95,38.68),("Alburquerque",-6.85,39.22)]),
    ("caceres",      "Qasr",           -6.37, 39.47, "d_marca_inf",
     [("Cáceres",-6.37,39.47),("Trujillo",-5.88,39.46),("Plasencia",-5.95,40.03)]),

    # ═══ GHARB AL-ANDALUS ═══
    ("lisboa",       "al-Ushbuna",     -9.14, 38.72, "d_gharb",
     [("Lisboa",-9.20,38.75),("Sintra",-9.35,38.92),("Almada",-9.05,38.52)]),
    ("santarem",     "Shantarin",      -8.69, 39.24, "d_gharb",
     [("Santarém",-8.69,39.24),("Abrantes",-8.10,39.46),("Tomar",-8.42,39.55)]),
    ("alcacer",      "al-Qasr",        -8.51, 38.37, "d_gharb",
     [("Alcácer do Sal",-8.48,38.35),("Setúbal",-8.90,38.48),("Grândola",-8.58,38.05)]),
    ("evora",        "Yabura",         -7.91, 38.57, "d_gharb",
     [("Évora",-7.95,38.55),("Estremoz",-7.65,38.82),("Montemor-o-Novo",-8.25,38.65),("Elvas",-7.40,38.85)]),
    ("beja",         "Baja",           -7.86, 38.02, "d_gharb",
     [("Beja",-7.86,38.05),("Serpa",-7.65,37.92),("Moura",-7.50,38.15),("Mértola",-7.70,37.55)]),
    ("silves",       "Shilb",          -8.44, 37.19, "d_gharb",
     [("Silves",-8.40,37.25),("Faro",-7.90,37.05),("Tavira",-7.55,37.15),("Lagos",-8.75,37.08)]),

    # ═══ CÓRDOBA ═══
    ("cordoba",      "Qurtuba",        -4.78, 37.89, "d_cordoba",
     [("Córdoba",-4.78,37.89),("Madinat al-Zahra",-4.87,37.89)]),
    ("cabra",        "Qabra",          -4.44, 37.47, "d_cordoba",
     [("Cabra",-4.44,37.47),("Lucena",-4.49,37.41),("Priego",-4.20,37.44)]),
    ("ecija",        "Istijja",        -5.08, 37.54, "d_cordoba",
     [("Écija",-5.08,37.54),("Osuna",-5.10,37.24)]),

    # ═══ SEVILHA ═══
    ("sevilla",      "Ishbiliyya",     -5.99, 37.39, "d_sevilla",
     [("Sevilha",-5.99,37.39),("Carmona",-5.64,37.47),("Alcalá de Guadaíra",-5.85,37.34)]),
    ("niebla",       "Labla",          -6.67, 37.36, "d_sevilla",
     [("Niebla",-6.67,37.36),("Huelva",-6.95,37.26),("Moguer",-6.84,37.28),("Lepe",-7.10,37.18)]),
    ("cadiz",        "Shadhuna",       -6.13, 36.69, "d_sevilla",
     [("Jerez",-6.13,36.69),("Cádiz",-6.29,36.53),("Medina Sidonia",-5.93,36.46),("Sanlúcar",-6.38,36.80)]),

    # ═══ JAÉN ═══
    ("jaen",         "Jayyan",         -3.79, 37.77, "d_jaen",
     [("Jaén",-3.79,37.77),("Andújar",-4.05,38.04),("Martos",-3.97,37.72)]),
    ("ubeda",        "Ubbada",         -3.37, 38.01, "d_jaen",
     [("Úbeda",-3.37,38.01),("Baeza",-3.47,37.99),("Linares",-3.64,38.10)]),

    # ═══ GRANADA ═══
    ("elvira",       "Ilbira",         -3.60, 37.18, "d_granada",
     [("Granada",-3.60,37.18),("Santa Fe",-3.72,37.19)]),
    ("guadix",       "Wadi Ash",       -3.13, 37.30, "d_granada",
     [("Guadix",-3.13,37.30),("Fiñana",-2.84,37.17)]),
    ("baza",         "Basta",          -2.77, 37.49, "d_granada",
     [("Baza",-2.77,37.49),("Huéscar",-2.54,37.81)]),
    ("loja",         "Lawsha",         -4.15, 37.17, "d_granada",
     [("Loja",-4.15,37.17),("Alhama",-3.99,37.01)]),

    # ═══ MÁLAGA ═══
    ("malaga",       "Malaqa",         -4.42, 36.72, "d_malaga",
     [("Málaga",-4.42,36.72),("Vélez-Málaga",-4.10,36.78)]),
    ("ronda",        "Runda",          -5.17, 36.74, "d_malaga",
     [("Ronda",-5.17,36.74),("Antequera",-4.56,37.02)]),
    ("algeciras",    "al-Jazira",      -5.45, 36.14, "d_malaga",
     [("Algeciras",-5.45,36.14),("Tarifa",-5.60,36.01),("Gibraltar",-5.35,36.14)]),

    # ═══ ALMERÍA ═══
    ("almeria",      "al-Mariyya",     -2.46, 36.83, "d_almeria",
     [("Almería",-2.46,36.83),("Berja",-2.95,36.85)]),
    ("vera",         "Bira",           -1.87, 37.25, "d_almeria",
     [("Vera",-1.87,37.25),("Mojácar",-1.85,37.13)]),

    # ═══ TUDMIR/MÚRCIA ═══
    ("murcia",       "Mursiya",        -1.13, 37.98, "d_tudmir",
     [("Múrcia",-1.13,37.98),("Orihuela",-0.94,38.08)]),
    ("lorca",        "Lurqa",          -1.70, 37.67, "d_tudmir",
     [("Lorca",-1.70,37.67),("Caravaca",-1.86,38.11)]),
    ("cartagena",    "Qartajanna",     -0.99, 37.61, "d_tudmir",
     [("Cartagena",-0.99,37.61),("Mazarrón",-1.31,37.60)]),
    ("alicante",     "Laqant",         -0.48, 38.35, "d_tudmir",
     [("Alicante",-0.48,38.35),("Elche",-0.70,38.27),("Dénia",0.11,38.84)]),

    # ═══ VALÊNCIA ═══
    ("valencia",     "Balansiya",      -0.38, 39.47, "d_valencia",
     [("Valência",-0.38,39.47),("Sagunto",-0.27,39.68)]),
    ("xativa",       "Shatiba",        -0.52, 38.99, "d_valencia",
     [("Xàtiva",-0.52,38.99),("Alcoi",-0.47,38.70),("Gandía",-0.18,38.97)]),
    ("castellon",    "Burriana",       -0.05, 39.99, "d_valencia",
     [("Castellón",-0.05,39.99),("Burriana",-0.08,39.89),("Segorbe",-0.49,39.85)]),

    # ═══ BALEARES ═══
    ("mallorca",     "Mayurqa",         2.65, 39.57, "d_baleares",
     [("Palma",2.65,39.57),("Alcúdia",3.12,39.85)]),
    ("menorca",      "Manurqa",         4.09, 39.95, "d_baleares",
     [("Maó",4.26,39.89),("Ciutadella",3.84,40.00)]),
]

if __name__ == "__main__":
    n_condados = len(CONDADOS)
    n_baronias = sum(len(c[5]) for c in CONDADOS)
    n_duchies = len(set(c[4] for c in CONDADOS))
    n_kingdoms = len(set(DUCHIES[c[4]][0] for c in CONDADOS))
    
    print(f"Condados: {n_condados}")
    print(f"Baronias: {n_baronias}")
    print(f"Ducados: {n_duchies}")
    print(f"Reinos: {n_kingdoms}")
    
    # Per duchy
    for did, (kid, dname) in sorted(DUCHIES.items()):
        conds = [c for c in CONDADOS if c[4] == did]
        if conds:
            bars = sum(len(c[5]) for c in conds)
            print(f"  {dname:30s}: {len(conds):2d} condados, {bars:3d} baronias [{kid}]")
